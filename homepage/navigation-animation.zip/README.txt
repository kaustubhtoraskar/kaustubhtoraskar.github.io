A Pen created at CodePen.io. You can find this one at http://codepen.io/EvyatarDa/pen/waKXMd.

 I was bored so I decided to play with animations...
Maybe i'll add more, comment for any ideas.

Enjoy that!